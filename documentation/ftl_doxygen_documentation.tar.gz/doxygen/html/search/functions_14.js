var searchData=
[
  ['xxtypebase_5fdefault_819',['xxtypebase_default',['../interfacebase_1_1base.html#a442e7bfd5876f45e3046a8f20391923e',1,'base::base::xxtypebase_default()'],['../namespacebase.html#a169ad4f5a78adc5102b8e6bc6e790069',1,'base::xxtypebase_default()']]]
];
