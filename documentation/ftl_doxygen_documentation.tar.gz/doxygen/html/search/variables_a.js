var searchData=
[
  ['vector_5fbase_5fcapacity_843',['vector_base_capacity',['../namespacevector.html#a811797779c391e1201e72a24b16daf2c',1,'vector']]],
  ['vector_5fbase_5fcapacity_5fincrease_844',['vector_base_capacity_increase',['../namespacevector.html#a839087d75888ee115bea9b101d24a09b',1,'vector']]]
];
