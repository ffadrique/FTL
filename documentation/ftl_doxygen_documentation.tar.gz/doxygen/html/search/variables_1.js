var searchData=
[
  ['data_823',['data',['../structvector_1_1t__base__vector.html#a3c8d088ffbf7e81b1c64afbf4b4bab1c',1,'vector::t_base_vector']]]
];
