var searchData=
[
  ['base_442',['base',['../namespacebase.html',1,'']]]
];
