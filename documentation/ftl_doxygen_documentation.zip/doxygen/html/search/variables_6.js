var searchData=
[
  ['next_831',['next',['../structlist_1_1t__list__node.html#ac86383f8fb9cb8c595a0be7a58c1f038',1,'list::t_list_node::next()'],['../structqueue_1_1t__node.html#a0514d9cccadeea3d16bf2d02f1ba77e1',1,'queue::t_node::next()'],['../structslist_1_1t__slist__node.html#acf0457a5cddc06996b8a030b51412374',1,'slist::t_slist_node::next()']]],
  ['next_5fsibling_832',['next_sibling',['../structtree_1_1t__tree__node.html#ac58d0553a1d196fe4396af9d02a62327',1,'tree::t_tree_node']]],
  ['node_833',['node',['../structlist_1_1t__base__list__iterator.html#aaead1fee0734e4d88f186f18a51f99c1',1,'list::t_base_list_iterator::node()'],['../structslist_1_1t__base__slist__iterator.html#abbbb64b7bc8f4b42a5940ba64b79ee54',1,'slist::t_base_slist_iterator::node()'],['../structtree_1_1t__base__tree__iterator.html#a3b5ec7b25a3b50fdac82b51e4cf01788',1,'tree::t_base_tree_iterator::node()']]]
];
