var searchData=
[
  ['first_825',['first',['../structlist_1_1t__base__list.html#aa32709a69dce546aebcfce6ceb29e215',1,'list::t_base_list::first()'],['../structqueue_1_1t__base__queue.html#ad1d885d74bacd772c4807b873f5004a3',1,'queue::t_base_queue::first()'],['../structslist_1_1t__base__slist.html#a3c57048098af2426d6b48f8a9886f7ee',1,'slist::t_base_slist::first()']]],
  ['first_5fchild_826',['first_child',['../structtree_1_1t__tree__node.html#aa33c674119d67557c8e4459fef58aced',1,'tree::t_tree_node']]]
];
