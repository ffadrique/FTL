var searchData=
[
  ['base_413',['base',['../interfacebase_1_1base.html',1,'base']]],
  ['binary_5fpredicate_414',['binary_predicate',['../interfacelist_1_1binary__predicate.html',1,'list::binary_predicate'],['../interfaceslist_1_1binary__predicate.html',1,'slist::binary_predicate'],['../interfacevector_1_1binary__predicate.html',1,'vector::binary_predicate']]]
];
